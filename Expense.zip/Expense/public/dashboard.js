let chart;
let income = 0;
let expense = 0;

const slider = document.getElementById("slider");
const sliderValue = document.getElementById("sliderValue");

// Sync slider with input
slider.oninput = function () {
  sliderValue.innerText = this.value;
  document.getElementById("amount").value = this.value;
};

document.getElementById("amount").addEventListener("input", function () {
  slider.value = this.value;
  sliderValue.innerText = this.value;
});

// Add Transaction
async function addTransaction() {
  const amount = document.getElementById("amount").value;
  const type = document.getElementById("type").value;
  const email = localStorage.getItem("userEmail");

  if (!amount) return alert("Enter amount");

  await fetch("/api/transaction/add", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, amount, type })
  });

  document.getElementById("amount").value = "";
  slider.value = 0;
  sliderValue.innerText = 0;

  fetchTransactions();
}

// Fetch Data from Firestore
async function fetchTransactions() {
  const email = localStorage.getItem("userEmail");

  const res = await fetch(`/api/transaction/${email}`);
  const data = await res.json();

  income = 0;
  expense = 0;

  data.forEach(t => {
    if (t.type === "income") income += t.amount;
    else expense += t.amount;
  });

  loadChart();
}

// Load Chart
function loadChart() {
  const ctx = document.getElementById("chart").getContext("2d");
  const chartType = document.getElementById("chartType").value;

  if (chart) chart.destroy();

  chart = new Chart(ctx, {
    type: chartType,
    data: {
      labels: ["Income", "Expense"],
      datasets: [{
        label: "Amount",
        data: [income, expense],
        backgroundColor: ["#1cc88a", "#e74a3b"]
      }]
    },
    options: {
      responsive: true
    }
  });
}

// Logout
function logout() {
  localStorage.removeItem("userEmail");
  window.location.href = "index.html";
}

// Auto load when page opens
fetchTransactions();
