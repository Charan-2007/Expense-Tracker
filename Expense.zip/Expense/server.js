const express = require("express");
const admin = require("firebase-admin");
const cors = require("cors");

const serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static("public"));


app.use("/api/auth", require("./routes/auth")(db));
app.use("/api/transaction", require("./routes/transaction")(db));

app.listen(5000, () => console.log("Server running on http://localhost:5000"));
