const bcrypt = require("bcryptjs");

module.exports = (db) => {
  const router = require("express").Router();

  // REGISTER
  router.post("/register", async (req, res) => {
    const { email, password } = req.body;

    const existing = await db.collection("users")
      .where("email", "==", email)
      .get();

    if (!existing.empty) {
      return res.status(400).json({ msg: "Email already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    await db.collection("users").add({
      email,
      password: hashedPassword
    });

    res.json({ msg: "Registered Successfully" });
  });

  // LOGIN
  router.post("/login", async (req, res) => {
    const { email, password } = req.body;

    const snapshot = await db.collection("users")
      .where("email", "==", email)
      .get();

    if (snapshot.empty) {
      return res.status(400).json({ msg: "User not found" });
    }

    const user = snapshot.docs[0].data();
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(400).json({ msg: "Wrong password" });
    }

    res.json({ msg: "Login success", email });
  });

  return router;
};
