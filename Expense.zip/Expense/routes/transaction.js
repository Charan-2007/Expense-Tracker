module.exports = (db) => {
  const router = require("express").Router();

  // ADD TRANSACTION
  router.post("/add", async (req, res) => {
    const { email, amount, type } = req.body;

    await db.collection("transactions").add({
      email,
      amount: Number(amount),
      type,
      createdAt: new Date()
    });

    res.json({ msg: "Transaction added" });
  });

  // GET USER TRANSACTIONS
  router.get("/:email", async (req, res) => {
    const snapshot = await db.collection("transactions")
      .where("email", "==", req.params.email)
      .get();

    const data = snapshot.docs.map(doc => doc.data());

    res.json(data);
  });

  return router;
};
